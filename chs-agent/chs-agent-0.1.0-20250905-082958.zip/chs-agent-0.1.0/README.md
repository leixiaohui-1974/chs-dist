# CHS-Agent 智能水利控制系统

## 项目概述

CHS-Agent 是一个基于多智能体系统的智能水利控制项目，采用分布式架构设计，实现水利设施的智能化监控、预测和控制。系统通过中央协调智能体、本地控制智能体、感知智能体和扰动框架等核心组件，提供完整的水利系统管理解决方案。

## 系统架构

### 核心组件

- **中央智能体 (Central Agents)**: 负责全局协调和优化决策
  - `central_mpc_agent.py`: 模型预测控制智能体，执行全局优化

- **本地智能体 (Local Agents)**: 负责具体设备的控制和监测
  - **控制模块**: 闸门、泵站、阀门等设备的精确控制
  - **感知模块**: 数据采集、状态监测和异常检测
  - **预测模块**: 基于LSTM和ARIMA的流量预测
  - **监督模块**: 应急响应和安全监控

- **扰动框架 (Disturbances)**: 模拟各种外部干扰和异常情况
  - 网络延迟和丢包模拟
  - 传感器噪声和执行器故障
  - 降雨和用水量变化模拟

## 主要特性

### 🚀 智能控制
- 模型预测控制 (MPC) 算法
- PID 控制器优化
- 多目标协同优化
- 实时响应和调节

### 📊 数据处理
- 实时数据采集和处理
- 卡尔曼滤波器状态估计
- 异常检测和数据清洗
- 历史数据分析

### 🔮 预测能力
- LSTM 深度学习预测
- ARIMA 时间序列分析
- 多步长预测
- 不确定性量化

### 🛡️ 可靠性保障
- 分布式架构设计
- 故障检测和恢复
- 冗余备份机制
- 应急响应系统

## 快速开始

### 环境要求

- Python 3.11+
- 依赖包：见 `requirements.txt`

### 安装步骤

1. **克隆项目**
   ```bash
   git clone <repository-url>
   cd chs-agent
   ```

2. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

3. **安装 chs-core 依赖**
   ```bash
   # 如果有本地 chs-core 包
   pip install /path/to/chs-core
   ```

4. **运行测试**
   ```bash
   python tests/test_runner.py
   ```

### Docker 部署

```bash
# 构建镜像
docker build -t chs-agent .

# 运行容器
docker run -p 8001:8001 chs-agent
```

## 项目结构

```
chs-agent/
├── central_agents/          # 中央协调智能体
│   └── central_mpc_agent.py
├── local_agents/            # 本地智能体
│   ├── control/            # 控制模块
│   ├── perception/         # 感知模块
│   ├── prediction/         # 预测模块
│   └── supervisory/        # 监督模块
├── disturbances/           # 扰动框架
│   ├── disturbance_framework.py
│   ├── network_disturbance.py
│   └── rainfall_agent.py
├── tests/                  # 测试文件
│   ├── test_basic_imports.py
│   ├── test_core_functionality.py
│   └── test_runner.py
├── requirements.txt        # 依赖列表
├── setup.py               # 安装配置
└── Dockerfile             # Docker 配置
```

## 使用示例

### 基本使用

```python
from central_agents.central_mpc_agent import CentralMPCAgent
from local_agents.control.gate_control_agent import GateControlAgent
from disturbances.disturbance_framework import DisturbanceManager

# 创建中央控制智能体
central_agent = CentralMPCAgent(agent_id="central_mpc")

# 创建本地控制智能体
gate_agent = GateControlAgent(agent_id="gate_001")

# 启动系统
central_agent.start()
gate_agent.start()
```

### 扰动测试

```python
from disturbances.disturbance_framework import DisturbanceConfig, DisturbanceType

# 配置网络延迟扰动
config = DisturbanceConfig(
    disturbance_id="network_delay_test",
    disturbance_type=DisturbanceType.NETWORK_DELAY,
    target_component_id="gate_001",
    start_time=0.0,
    end_time=60.0,
    intensity=0.5,
    parameters={"delay_ms": 100}
)

# 应用扰动
disturbance_manager.apply_disturbance(config)
```

## 测试

项目包含完整的测试套件：

- **基础测试**: 语法检查、包结构验证
- **功能测试**: 核心模块功能验证
- **集成测试**: 模块间交互测试

运行所有测试：
```bash
python tests/test_runner.py
```

查看测试覆盖率：
```bash
coverage run tests/test_runner.py
coverage report
```

## 配置

系统支持通过配置文件进行自定义：

```yaml
# config.yaml
message_bus:
  max_workers: 4
  queue_size: 1000
  batch_size: 10

data_processing:
  cache_size: 128
  anomaly_threshold: 2.0
  smoothing_window: 3

logging:
  level: INFO
  format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
```

## 性能优化

项目实现了多项性能优化：

- **异步消息处理**: 提升消息传递效率
- **数据缓存机制**: 减少重复计算
- **对象池模式**: 降低内存分配开销
- **向量化计算**: 加速数据处理

详细优化建议请参考 [OPTIMIZATION_RECOMMENDATIONS.md](OPTIMIZATION_RECOMMENDATIONS.md)

## 问题排查

常见问题及解决方案：

### 依赖问题
```bash
# ModuleNotFoundError: No module named 'core_lib'
# 解决方案：安装 chs-core 包或使用模拟模块
pip install /path/to/chs-core
```

### 测试失败
```bash
# 检查测试环境
python tests/test_basic_imports.py
```

更多问题请参考 [ISSUES_AND_FIXES.md](ISSUES_AND_FIXES.md)

## 贡献指南

欢迎贡献代码！请遵循以下步骤：

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

### 代码规范

- 使用 Python 3.11+ 语法
- 遵循 PEP 8 代码风格
- 添加完整的文档字符串
- 编写相应的单元测试

## 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

## 联系方式

- 项目维护者: [维护者姓名]
- 邮箱: [email@example.com]
- 项目主页: [项目URL]

## 更新日志

### v0.1.0 (当前版本)
- ✅ 基础架构实现
- ✅ 核心智能体模块
- ✅ 扰动框架
- ✅ 测试套件
- ✅ Docker 支持

### 计划功能
- 🔄 Web 管理界面
- 🔄 实时监控面板
- 🔄 高级预测算法
- 🔄 云端部署支持

---

**注意**: 本项目仍在积极开发中，API 可能会发生变化。建议在生产环境使用前进行充分测试。